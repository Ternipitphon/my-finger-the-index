# -*- coding: utf-8 -*-
"""Whisper audio transcription with explicit provider routing.

Downloads audio (yt-dlp), compresses + chunks (ffmpeg), and posts to a
Whisper-compatible API. Auto mode selects the first configured provider and
only sends audio to another provider when the caller explicitly opts in.

Public entry point:
    transcribe(
        source,
        *,
        provider="auto",
        out_dir=None,
        config=None,
        allow_provider_fallback=False,
    ) -> str

Designed to be importable from channels (e.g. YouTubeChannel.transcribe).
"""

from __future__ import annotations

import ipaddress
import math
import re
import socket
import subprocess
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlparse

import requests

from agent_reach.config import Config

# Whisper API limit is 25MB; leave headroom for multipart overhead.
SIZE_LIMIT_BYTES = 24 * 1024 * 1024
CHUNK_SECONDS = 600  # 10 min — small enough that boundary cuts rarely lose meaning
MAX_SOURCE_BYTES = 512 * 1024 * 1024
MAX_CHUNKS = 24  # 4 hours at the standard 10-minute segment size
MAX_TOTAL_CHUNK_BYTES = 96 * 1024 * 1024
MAX_AUDIO_SECONDS = MAX_CHUNKS * CHUNK_SECONDS
PROBE_TIMEOUT_SECONDS = 30

PROVIDERS = {
    "groq": {
        "endpoint": "https://api.groq.com/openai/v1/audio/transcriptions",
        "model": "whisper-large-v3",
        "key_field": "groq_api_key",
    },
    "openai": {
        "endpoint": "https://api.openai.com/v1/audio/transcriptions",
        "model": "whisper-1",
        "key_field": "openai_api_key",
    },
}


class TranscribeError(RuntimeError):
    """Raised when transcription cannot complete."""


class MissingDependency(TranscribeError):
    """Raised when a required external binary is missing."""


class NoProviderConfigured(TranscribeError):
    """Raised when no provider has an API key configured."""


_BLOCKED_HOSTS = {
    "localhost",
    "metadata.google.internal",
}


def _bin(binary: str) -> str:
    """Our private copy (e.g. the ffmpeg `agent-reach add` installs) first, then PATH."""
    from agent_reach.runtime.tools import resolve

    return resolve(binary) or binary


def _require(binary: str) -> None:
    from agent_reach.runtime.tools import resolve

    if not resolve(binary):
        raise MissingDependency(f"{binary} not found (run `agent-reach add youtube`)")


def _require_size_at_most(path: Path, limit: int, label: str) -> int:
    """Return file size or fail before expensive downstream processing."""
    size = path.stat().st_size
    if size > limit:
        limit_mib = limit / (1024 * 1024)
        raise TranscribeError(f"{label} exceeds safety limit of {limit_mib:g} MiB")
    return size


_DURATION_RE = re.compile(r"Duration:\s*(\d+):(\d{2}):(\d{2}(?:\.\d+)?)")


def _probe_audio_duration(path: Path) -> float:
    """Return duration in seconds or fail closed before media generation.

    Read from `ffmpeg -i` (no ffprobe: the private ffmpeg Agent Reach installs
    ships only ffmpeg). Without an output file ffmpeg exits 1 after printing
    the input's details, so the exit code is not checked.
    """
    _require("ffmpeg")
    cmd = [_bin("ffmpeg"), "-hide_banner", "-i", str(path)]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=PROBE_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        raise TranscribeError(
            "ffmpeg timed out while reading audio duration "
            f"after {PROBE_TIMEOUT_SECONDS}s"
        ) from None
    except OSError as exc:
        raise TranscribeError(
            f"ffmpeg could not read audio duration: {exc}"
        ) from exc

    m = _DURATION_RE.search(proc.stderr or "")
    if not m:
        raise TranscribeError("ffmpeg could not parse a valid audio duration")
    duration = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    if not math.isfinite(duration) or duration <= 0:
        raise TranscribeError(
            "ffmpeg could not parse a valid positive audio duration"
        )
    return duration


def _require_duration_within_budget(path: Path) -> float:
    """Reject audio that cannot fit within the bounded chunk budget."""
    duration = _probe_audio_duration(path)
    if duration > MAX_AUDIO_SECONDS:
        max_minutes = MAX_AUDIO_SECONDS // 60
        raise TranscribeError(
            f"audio duration exceeds safety limit of {max_minutes} minutes"
        )
    return duration


def _run(cmd: List[str], timeout: int = 600) -> None:
    """Run a subprocess, raising TranscribeError on nonzero exit or timeout.

    cmd carries user-supplied URLs/paths into yt-dlp/ffmpeg — a stalled
    network read or a hung probe must not block the CLI forever.
    """
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        raise TranscribeError(f"{cmd[0]} timed out after {timeout}s")
    if proc.returncode != 0:
        raise TranscribeError(
            f"{cmd[0]} failed (exit {proc.returncode}): {proc.stderr.strip()[:300]}"
        )


def _literal_ip(host: str):
    """Return the address a literal host denotes, or None for a real hostname.

    ``ipaddress`` only accepts the canonical dotted-quad form, but the C
    resolver behind yt-dlp accepts the whole ``inet_aton`` grammar: ``127.1``,
    ``2130706433``, ``0x7f000001`` and ``0177.0.0.1`` all reach 127.0.0.1, and
    ``0xA9FEA9FE`` reaches the cloud metadata endpoint. Parsing with the same
    grammar keeps those shorthands from slipping past the private-address
    check. This is literal parsing only — no name is resolved here.
    """
    try:
        return ipaddress.ip_address(host)
    except ValueError:
        pass
    try:
        packed = socket.inet_aton(host)
    except OSError:
        return None
    return ipaddress.IPv4Address(packed)


def _is_private_ip(value: str) -> bool:
    ip = _literal_ip(value)
    if ip is None:
        return False
    return any(
        (
            ip.is_private,
            ip.is_loopback,
            ip.is_link_local,
            ip.is_reserved,
            ip.is_multicast,
            ip.is_unspecified,
        )
    )


def _assert_safe_public_url(url: str) -> None:
    """Reject literal local/internal URLs without DNS-resolving public hosts."""
    if "://" not in url:
        before_slash = url.split("/", 1)[0]
        if ":" in before_slash:
            host_part, port_part = before_slash.rsplit(":", 1)
            if not host_part or not port_part.isdigit():
                raise TranscribeError("SSRF blocked: only public http(s) URLs are allowed")
        normalized_url = f"https://{url}"
        parsed = urlparse(normalized_url)
    else:
        normalized_url = url
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"}:
            raise TranscribeError("SSRF blocked: only public http(s) URLs are allowed")

    raw_authority = normalized_url.split("://", 1)[1]
    raw_authority = raw_authority.split("/", 1)[0]
    raw_authority = raw_authority.split("?", 1)[0]
    raw_authority = raw_authority.split("#", 1)[0]
    if "\\" in raw_authority or "%" in raw_authority:
        raise TranscribeError("SSRF blocked: encoded or ambiguous URL host")

    raw_host = (parsed.hostname or "").strip().rstrip(".")
    if not raw_host:
        raise TranscribeError("SSRF blocked: URL host is missing")
    try:
        host = raw_host.encode("idna").decode("ascii").lower().rstrip(".")
    except UnicodeError:
        raise TranscribeError("SSRF blocked: URL host is invalid") from None
    if host in _BLOCKED_HOSTS or host.endswith(".localhost"):
        raise TranscribeError("SSRF blocked: internal host is not allowed")
    if _is_private_ip(host):
        raise TranscribeError("SSRF blocked: private/internal IP is not allowed")


def download_audio(url: str, out_dir: Path) -> Path:
    """Download audio with yt-dlp into out_dir; return the resulting file path."""
    _assert_safe_public_url(url)
    import sys

    template = out_dir / "source.%(ext)s"
    _run(
        [
            sys.executable, "-m", "yt_dlp",
            "-x",
            "--audio-format",
            "m4a",
            "--audio-quality",
            "0",
            "--no-playlist",
            "--ffmpeg-location",
            _bin("ffmpeg"),
            "--max-filesize",
            str(MAX_SOURCE_BYTES),
            "-o",
            str(template),
            "--",
            url,
        ],
        timeout=1800,  # long podcasts over slow networks — generous but bounded
    )
    files = sorted(out_dir.glob("source.*"))
    if not files:
        limit_mib = MAX_SOURCE_BYTES // (1024 * 1024)
        raise TranscribeError(
            f"yt-dlp produced no output file (source may exceed {limit_mib} MiB limit)"
        )
    audio = files[0]
    _require_size_at_most(audio, MAX_SOURCE_BYTES, "downloaded source")
    return audio


def compress_audio(src: Path, out_dir: Path) -> Path:
    """Re-encode to mono / 16kHz / 32kbps m4a — keeps most content under 25MB."""
    _require("ffmpeg")
    dst = out_dir / "compressed.m4a"
    _run(
        [
            _bin("ffmpeg"),
            "-loglevel",
            "error",
            "-y",
            "-i",
            str(src),
            "-t",
            str(MAX_AUDIO_SECONDS),
            "-vn",
            "-ac",
            "1",
            "-ar",
            "16000",
            "-b:a",
            "32k",
            str(dst),
        ]
    )
    return dst


def chunk_audio(src: Path, out_dir: Path, segment_seconds: int = CHUNK_SECONDS) -> List[Path]:
    """Split src into segments. Re-encodes each segment so cuts align to keyframes."""
    if segment_seconds <= 0:
        raise TranscribeError("chunk segment duration must be positive")
    possible_chunks = (
        MAX_AUDIO_SECONDS + segment_seconds - 1
    ) // segment_seconds
    if possible_chunks > MAX_CHUNKS:
        raise TranscribeError(
            f"chunk generation safety limit is {MAX_CHUNKS}; "
            f"segment duration {segment_seconds}s could create "
            f"{possible_chunks} chunks"
        )
    _require("ffmpeg")
    pattern = out_dir / "chunk_%03d.m4a"
    _run(
        [
            _bin("ffmpeg"),
            "-loglevel",
            "error",
            "-y",
            "-i",
            str(src),
            "-t",
            str(MAX_AUDIO_SECONDS),
            "-f",
            "segment",
            "-segment_time",
            str(segment_seconds),
            "-ac",
            "1",
            "-ar",
            "16000",
            "-b:a",
            "32k",
            str(pattern),
        ]
    )
    chunks = sorted(out_dir.glob("chunk_*.m4a"))
    if not chunks:
        raise TranscribeError("ffmpeg produced no chunks")
    return chunks


def _provider_key(provider: str, config: Config) -> Optional[str]:
    field = PROVIDERS[provider]["key_field"]
    val = config.get(field)
    return val or None


def transcribe_chunk(
    chunk: Path,
    provider: str,
    *,
    config: Optional[Config] = None,
    timeout: int = 120,
) -> str:
    """Transcribe one chunk via the named provider. Raises TranscribeError on failure."""
    if provider not in PROVIDERS:
        raise TranscribeError(f"unknown provider: {provider}")
    cfg = config or Config()
    key = _provider_key(provider, cfg)
    if not key:
        raise NoProviderConfigured(
            f"{provider}: missing {PROVIDERS[provider]['key_field']} "
            f"(configure with `agent-reach configure {provider}-key ...`)"
        )

    info = PROVIDERS[provider]
    with chunk.open("rb") as fh:
        try:
            resp = requests.post(
                info["endpoint"],
                headers={"Authorization": f"Bearer {key}"},
                files={"file": (chunk.name, fh, "audio/m4a")},
                data={"model": info["model"], "response_format": "text"},
                timeout=timeout,
            )
        except requests.RequestException as e:
            raise TranscribeError(f"{provider}: network error: {e}") from e

    if not resp.ok:
        raise TranscribeError(f"{provider}: HTTP {resp.status_code}: {resp.text[:300]}")
    return resp.text


def _provider_order(provider: str) -> List[str]:
    if provider == "auto":
        return ["groq", "openai"]
    if provider in PROVIDERS:
        return [provider]
    raise TranscribeError(f"unknown provider: {provider} (use groq|openai|auto)")


def transcribe(
    source: str,
    *,
    provider: str = "auto",
    out_dir: Optional[Path] = None,
    config: Optional[Config] = None,
    allow_provider_fallback: bool = False,
) -> str:
    """Transcribe a URL or local file path. Returns the joined transcript text.

    `provider` is one of `auto`, `groq`, or `openai`. Auto mode selects the
    first configured provider (Groq, then OpenAI). In auto mode only, set
    `allow_provider_fallback=True` to permit sending failed chunks to the next
    configured provider; using the flag with an explicit provider is rejected.
    `out_dir` defaults to a fresh temp directory; intermediate files stay there.
    """
    if allow_provider_fallback and provider != "auto":
        raise TranscribeError(
            "allow_provider_fallback requires provider='auto'"
        )
    cfg = config or Config()
    candidates = _provider_order(provider)
    configured = [p for p in candidates if _provider_key(p, cfg)]

    # Validate at least one provider is configured before doing expensive work.
    if not configured:
        names = ", ".join(PROVIDERS[p]["key_field"] for p in candidates)
        raise NoProviderConfigured(f"no provider key configured (need one of: {names})")

    order = configured
    if provider == "auto" and not allow_provider_fallback:
        order = configured[:1]

    if out_dir:
        return _transcribe_in_dir(source, order, cfg, Path(out_dir))

    from agent_reach.utils.paths import private_temporary_directory

    with private_temporary_directory(prefix="transcribe-") as tmp:
        return _transcribe_in_dir(source, order, cfg, Path(tmp))


def _transcribe_in_dir(source: str, order: List[str], cfg: Config, work_dir: Path) -> str:
    work_dir.mkdir(parents=True, exist_ok=True)

    src_path = Path(source)
    if src_path.is_file():
        audio = src_path
    else:
        audio = download_audio(source, work_dir)

    _require_size_at_most(audio, MAX_SOURCE_BYTES, "source")
    _require_duration_within_budget(audio)
    compressed = compress_audio(audio, work_dir)
    if compressed.stat().st_size <= SIZE_LIMIT_BYTES:
        chunks = [compressed]
    else:
        chunks = chunk_audio(compressed, work_dir)

    if len(chunks) > MAX_CHUNKS:
        max_minutes = MAX_CHUNKS * CHUNK_SECONDS // 60
        raise TranscribeError(
            f"audio produced {len(chunks)} chunks; safety limit is "
            f"{MAX_CHUNKS} (~{max_minutes} minutes)"
        )
    chunk_sizes = [
        _require_size_at_most(chunk, SIZE_LIMIT_BYTES, f"chunk {chunk.name}")
        for chunk in chunks
    ]
    total_chunk_bytes = sum(chunk_sizes)
    if total_chunk_bytes > MAX_TOTAL_CHUNK_BYTES:
        limit_mib = MAX_TOTAL_CHUNK_BYTES / (1024 * 1024)
        raise TranscribeError(
            f"audio chunks total {total_chunk_bytes} bytes; "
            f"safety limit is {limit_mib:g} MiB"
        )

    pieces: List[str] = []
    for chunk in chunks:
        text = _transcribe_with_fallback(chunk, order, cfg)
        pieces.append(text.strip())
    return "\n".join(p for p in pieces if p)


def _transcribe_with_fallback(chunk: Path, order: List[str], config: Config) -> str:
    """Try each provider in order; return first success or raise the last error."""
    last_err: Optional[Exception] = None
    for p in order:
        if not _provider_key(p, config):
            # Skip silently — caller already validated at least one is configured.
            continue
        try:
            return transcribe_chunk(chunk, p, config=config)
        except TranscribeError as e:
            last_err = e
            continue
    raise TranscribeError(f"all providers failed for {chunk.name}: {last_err}")
