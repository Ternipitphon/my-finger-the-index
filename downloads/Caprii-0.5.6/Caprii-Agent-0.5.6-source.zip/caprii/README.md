# Caprii 0.5.6

รุ่นติดตั้ง Windows x64 พร้อม DOM forms และ Test Lab ในแอป คลิกขวาตัวละคร → เปิดเว็บทดสอบ Caprii ไม่ต้องติดตั้ง Node.js เพิ่ม

# Caprii 0.5.2

ผู้ช่วยบนเดสก์ท็อปที่คุยภาษาไทย อ่านจอ ทำโจทย์ และใช้เครื่องมือโดยตรวจผลจริง

- คำสั่งสั้นพร้อมบริบทเฉพาะแชตปัจจุบัน ไม่เดางานเมื่อบริบทไม่ชัด และไม่กรอก/ส่งเมื่อขอเพียงคำอธิบาย
- แก้ช่อง read-only ผ่านแป้นเว็บ พร้อมหลักฐานค่าช่องเดิม และหยุดการลองซ้ำเมื่อผลไม่แน่ชัด
- ปุ่มพิมพ์คำสั่งด้วยเสียงผ่าน Windows Voice Typing แบบเลือกเริ่มเอง ตรวจข้อความก่อนส่ง (ต้องตรวจบน Windows จริง)
- บทพูดไทย 477 รายการ และการกำกับคำตอบให้เป็นไทยโดยคงโค้ด/เลข/ชื่อโปรแกรมตามจริง
- ตัวเลือกอ่านออกเสียงด้วยเสียงไทยแบบ local ไม่ใช้เสียงอังกฤษหรือส่งไปบริการอ่านเสียงอื่นแทน
- ส่วนขยาย Chrome แบบเลือกแท็บเอง เชื่อมด้วยรหัสที่หมดอายุเมื่อปิดแอป ไม่ขอสิทธิ์อ่านทุกเว็บไซต์
- กรอกช่องแล้วอ่านค่ากลับ รองรับแป้นบนเว็บเมื่อช่อง read-only และตรวจผลหลังส่งแยกจากการพิมพ์
- คิดเลขด้วยเครื่องมือจริง ปฏิเสธคำตอบเดา และไม่ถือว่าคำนวณได้เท่ากับกรอก/ส่งแล้ว
- โหมดไม่ถามแบบเลือกเปิดเองต่อรอบ ปุ่มหยุดและ Ctrl+Alt+Esc ยังทำงาน ไม่เพิ่ม Memory ข้ามงาน

อ่าน [คู่มือไทย](CAPRII-TH.md) และ [หลักฐาน/ข้อจำกัดการทดสอบ](VALIDATION.md)

## พัฒนา

ใช้ Node.js 24 และ `npm ci` จากโฟลเดอร์นี้ รัน `npm test` สำหรับชุดทดสอบ หากมี X11/หน้าจอจริง รัน `npm run test:electron`, `npm run test:chrome-ui`, `npm run test:site-ui` สำหรับฟอร์ม/การเชื่อมต่อ/แอปจริง `npm run test:windows` ต้องรันใน Windows ที่เปิดหน้าจออยู่

สร้าง Windows x64 ด้วย `npm run dist:cloud` ใน cloud ใช้ `NODE_USE_ENV_PROXY=1` และรักษาการตรวจ TLS/ลายเซ็น/เช็กซัมตามระบบ ไม่ถือว่าการสร้างบน Linux ยืนยันการติดตั้งหรือการควบคุม Windows จริง

ซอร์สส่วนขยายอยู่ที่ `browser-extension/` และใช้ DOM bridge เดียวกับเบราว์เซอร์ Electron ใน `src/shared/browser-dom.js` หากเปลี่ยน bridge ให้คัดลอกไป `browser-extension/dom.js` ด้วย ชุดทดสอบตรวจว่าไฟล์ตรงกัน รักษา public key ใน manifest และ ID ที่ตรึงไว้ให้ตรงกัน ไม่สร้าง ID ใหม่ทุกครั้งที่ build

Chrome broker ฟังเฉพาะ loopback หลังผู้ใช้เลือกเชื่อม รหัสเกิดใหม่ทุกครั้งที่เปิดโปรแกรม ไม่บันทึกคีย์ลงไฟล์หรือ log คำสั่งรองรับเฉพาะอ่าน/กรอก/คลิก/ตรวจค่า ไม่มีเครื่องมือ eval หรือ shell ผ่านส่วนขยาย

## DOM forms (0.5.6)

Read [DOM-FORMS-TH.md](DOM-FORMS-TH.md) for selected-tab reading, text/dropdown/checkbox/radio input, exact field readback, scoped result checks, and local browser validation. Included in the 0.5.6 Windows installer.

## Caprii Test Lab

Run `npm run lab`, open `http://127.0.0.1:5173` in Chrome, connect that tab to Caprii, and copy a test prompt. See [test-lab/README-TH.md](test-lab/README-TH.md) for seven versioned regression cases and JSON evidence reports. Installed users can choose เปิดเว็บทดสอบ Caprii from the tray menu without installing Node.js. The lab runs locally and is updated alongside capability changes.
